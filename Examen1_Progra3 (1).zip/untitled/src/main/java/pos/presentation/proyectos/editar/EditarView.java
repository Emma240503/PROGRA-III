package pos.presentation.proyectos.editar;

import pos.logic.Tarea;

import javax.swing.*;
import java.awt.event.*;

public class EditarView extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JComboBox<String> comboBoxPrioridad;
    private JComboBox<String> comboBoxEstado;

    private boolean confirmado = false;
    private Tarea tarea;

    public EditarView(JFrame parent, Tarea tarea) {
        super(parent, "Editar Tarea", true);
        this.tarea = tarea;

        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);


        comboBoxPrioridad.addItem("Alta");
        comboBoxPrioridad.addItem("Media");
        comboBoxPrioridad.addItem("Baja");

        comboBoxEstado.addItem("Pendiente");
        comboBoxEstado.addItem("En proceso");
        comboBoxEstado.addItem("Finalizada");
        comboBoxEstado.addItem("Cancelada");

        comboBoxPrioridad.setSelectedItem(tarea.getPrioridad());
        comboBoxEstado.setSelectedItem(tarea.getEstado());

        buttonOK.addActionListener(e -> onOK());
        buttonCancel.addActionListener(e -> onCancel());

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        contentPane.registerKeyboardAction(e -> onCancel(),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        pack();
        setLocationRelativeTo(parent);
    }

    private void onOK() {
        confirmado = true;
        tarea.setPrioridad((String) comboBoxPrioridad.getSelectedItem());
        tarea.setEstado((String) comboBoxEstado.getSelectedItem());
        dispose();
    }

    private void onCancel() {
        confirmado = false;
        dispose();
    }

    public boolean isConfirmado() {
        return confirmado;
    }

    public String getNuevaPrioridad() {
        return (String) comboBoxPrioridad.getSelectedItem();
    }

    public String getNuevoEstado() {
        return (String) comboBoxEstado.getSelectedItem();
    }
}
