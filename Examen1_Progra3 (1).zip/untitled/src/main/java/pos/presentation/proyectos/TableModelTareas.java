package pos.presentation.proyectos;
import pos.logic.Proyecto;
import pos.logic.Tarea;
import pos.presentation.AbstractTableModel;
import java.util.List;

public class TableModelTareas extends AbstractTableModel<Tarea> implements javax.swing.table.TableModel {
    public TableModelTareas(int[] cols, List<Tarea> rows) {
        super(cols, rows);
    }

    public static final int CODIGO = 0;
    public static final int DESCRIPCION = 1;
    public static final int FECHA = 2;
    public static final int PRIORIDAD = 3;
    public static final int ESTADO = 4;
    public static final int ENCARGADO = 5;


    @Override
    protected Object getPropetyAt(Tarea e, int col) {
        switch (cols[col]) {
            case CODIGO: return e.getId();
            case DESCRIPCION: return e.getDescripcion();
            case FECHA: return e.getFecha();
            case PRIORIDAD: return e.getPrioridad();
            case ESTADO: return e.getEstado();
            case ENCARGADO: return e.getUsuario().getNombre();
            default: return "";
        }
    }


    @Override
    protected void initColNames() {
        colNames = new String[6];
        colNames[CODIGO] = "Codigo";
        colNames[DESCRIPCION] = "Descripcion";
        colNames[FECHA] = "Fecha";
        colNames[PRIORIDAD] = "Prioridad";
        colNames[ESTADO] = "Estado";
        colNames[ENCARGADO] = "Encargado";
    }
}

