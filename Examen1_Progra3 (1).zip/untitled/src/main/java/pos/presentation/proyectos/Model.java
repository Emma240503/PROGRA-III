
package pos.presentation.proyectos;

import pos.logic.Proyecto;
import pos.logic.Tarea;
import pos.logic.Service;
import pos.logic.Usuario;
import pos.presentation.AbstractModel;

import java.beans.PropertyChangeListener;
import java.util.List;

public class Model extends AbstractModel {

    private List<Proyecto> proyectos;
    private Proyecto current;
    private List<Tarea> tareasProyecto;
    private int mode;

    public static final String PROYECTOS = "proyectos";
    public static final String PROYECTO_ACTUAL = "proyectoActual";

    public static final String TAREAS_PROYECTO = "tareasProyecto";

    private Service service;

    public Model() {
        service = Service.instance();
        proyectos = service.findAll();
        current = proyectos.isEmpty() ? null : proyectos.get(0);
        actualizarTareasProyecto();
    }

    @Override
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        super.addPropertyChangeListener(listener);
        firePropertyChange(PROYECTOS);
        firePropertyChange(PROYECTO_ACTUAL);
        firePropertyChange(TAREAS_PROYECTO);
    }

    public List<Proyecto> getProyectos() { return proyectos; }
    public Proyecto getCurrent() { return current; }
    public List<Tarea> getTareasProyecto() { return tareasProyecto; }
    public List<Usuario> getUsuarios() {
        return service.getData().getUsuarios();
    }
    public int getMode() { return mode; }
    public void setMode(int mode) { this.mode = mode; }

    public void setCurrent(Proyecto proyecto) {
        this.current = proyecto;
        actualizarTareasProyecto();
        firePropertyChange(PROYECTO_ACTUAL);
    }

    public void actualizarProyectos() {
        proyectos = service.findAll();

        if (!proyectos.isEmpty()) {

            current = proyectos.get(0);
        } else {
            current = null;
        }

        actualizarTareasProyecto();
        firePropertyChange(PROYECTOS);
    }


    public void setTareasProyecto(List<Tarea> tareas) {
        this.tareasProyecto = tareas;
        firePropertyChange(TAREAS_PROYECTO);
    }





    /*public void actualizarTareasProyecto() {
        tareasProyecto = service.findAllTareas(); // siempre todas las tareas
        firePropertyChange(TAREAS_PROYECTO);
    }
*/
    public void actualizarTareasProyecto() {
        if (current != null) {
            tareasProyecto = current.getTareas();
        } else {
            tareasProyecto = List.of();
        }
        firePropertyChange(TAREAS_PROYECTO);
    }




}
