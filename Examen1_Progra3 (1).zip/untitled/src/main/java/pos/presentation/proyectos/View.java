package pos.presentation.proyectos;

import pos.Application;
import pos.logic.Proyecto;
import pos.logic.Tarea;
import pos.logic.Usuario;
import pos.presentation.proyectos.editar.EditarView;
import java.awt.*;
import java.util.UUID;
import javax.swing.*;
import javax.swing.table.TableColumnModel;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;

public class View implements PropertyChangeListener {
    private JPanel panel1;
    private JButton crearButton;
    private JTextField textFieldDescripcionProyecto;
    private JComboBox<Usuario> comboBoxUsuarioProyecto;
    private JTable tableProyectos;
    private JButton crearTareaButton;
    private JTextField textFieldDescripcionTarea;
    private JComboBox<Usuario> comboBoxUsuarioTareas;
    private JTable tableTareas;
    private JTextField textFieldprioridad;
    private JTextField textFieldFecha;
    private JComboBox<String> comboBoxPrioridad;
    private JComboBox<String> comboBoxEstado;

    private JTextField textFieldEstado;
    private JLabel labelNumTareas;

    Controller controller;
    Model model;

    public View() {
        comboBoxPrioridad.removeAllItems();
        comboBoxPrioridad.addItem("Alta");
        comboBoxPrioridad.addItem("Media");
        comboBoxPrioridad.addItem("Baja");

        comboBoxEstado.removeAllItems();
        comboBoxEstado.addItem("Pendiente");
        comboBoxEstado.addItem("En proceso");
        comboBoxEstado.addItem("Finalizada");
        comboBoxEstado.addItem("Cancelada");

        crearButton.addActionListener(e -> {
            try {
                if (!validarCasilla(textFieldDescripcionProyecto)) return;

                String id = UUID.randomUUID().toString().substring(0, 5);
                String descripcion = textFieldDescripcionProyecto.getText();
                Usuario encargado = (Usuario) comboBoxUsuarioProyecto.getSelectedItem();

                Proyecto proyecto = new Proyecto(descripcion, encargado, id);
                controller.crearProyecto(proyecto);

                textFieldDescripcionProyecto.setText("");
                comboBoxUsuarioProyecto.setSelectedIndex(0);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel1, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        crearTareaButton.addActionListener(e -> {
            try {
                boolean descripcionValida = validarCasilla(textFieldDescripcionTarea);
                boolean fechaValida = validarCasilla(textFieldFecha);
                if (!descripcionValida || !fechaValida) return;

                String id = UUID.randomUUID().toString().substring(0,5);
                String descripcion = textFieldDescripcionTarea.getText();
                String fecha = textFieldFecha.getText();
                String prioridad = (String) comboBoxPrioridad.getSelectedItem();
                String estado = (String) comboBoxEstado.getSelectedItem();
                Usuario encargado = (Usuario) comboBoxUsuarioTareas.getSelectedItem();

                Tarea tarea = new Tarea(id, descripcion, fecha, estado, prioridad, encargado);
                controller.crearTarea(tarea);

                textFieldDescripcionTarea.setText("");
                textFieldFecha.setText("");
                comboBoxPrioridad.setSelectedIndex(0);
                comboBoxEstado.setSelectedIndex(0);
                comboBoxUsuarioTareas.setSelectedIndex(0);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel1, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        tableTareas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 1) {
                    int fila = tableTareas.getSelectedRow();
                    if (fila >= 0) {
                        Tarea tarea = model.getTareasProyecto().get(fila);
                        EditarView dialog = new EditarView((JFrame) SwingUtilities.getWindowAncestor(panel1), tarea);
                        dialog.setVisible(true);
                        if (dialog.isConfirmado()) {
                            cargarTableTareas();
                        }
                    }
                }
            }
        });

        tableProyectos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int fila = tableProyectos.getSelectedRow();
                if (fila >= 0) {
                    Proyecto proyecto = model.getProyectos().get(fila);
                    model.setCurrent(proyecto);
                }
            }
        });

    }

    public JPanel getPanel() {
        return panel1;
    }

    public void setController(Controller controller) {
        this.controller = controller;
    }

    public void setModel(Model model) {
        this.model = model;
        model.addPropertyChangeListener(this);
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        switch (evt.getPropertyName()) {
            case Model.PROYECTOS -> {
                cargarTableProyectos();
                cargarComboBoxUsuarios();
            }
            case Model.PROYECTO_ACTUAL, Model.TAREAS_PROYECTO -> cargarTableTareas();
        }
    }

    private void cargarComboBoxUsuarios() {
        List<Usuario> usuarios = model.getUsuarios();
        comboBoxUsuarioProyecto.removeAllItems();
        comboBoxUsuarioTareas.removeAllItems();
        for (Usuario u : usuarios) {
            comboBoxUsuarioProyecto.addItem(u);
            comboBoxUsuarioTareas.addItem(u);
        }
    }

    private void cargarTableProyectos() {
        int[] cols = {TableModelProyecto.CODIGO, TableModelProyecto.DESCRIPCION,
                TableModelProyecto.ENCARGADO, TableModelProyecto.NUMEROTAREAS};
        tableProyectos.setModel(new TableModelProyecto(cols, model.getProyectos()));
        tableProyectos.setRowHeight(25);

        TableColumnModel columnModel = tableProyectos.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(50);
        columnModel.getColumn(1).setPreferredWidth(200);
        columnModel.getColumn(2).setPreferredWidth(100);
        columnModel.getColumn(3).setPreferredWidth(80);


    }

    private void cargarTableTareas() {
        int[] cols = {TableModelTareas.CODIGO, TableModelTareas.DESCRIPCION,
                TableModelTareas.FECHA, TableModelTareas.PRIORIDAD,
                TableModelTareas.ESTADO, TableModelTareas.ENCARGADO};
        tableTareas.setModel(new TableModelTareas(cols, model.getTareasProyecto()));
        tableTareas.setRowHeight(25);

        TableColumnModel columnModel = tableTareas.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(50);
        columnModel.getColumn(1).setPreferredWidth(200);
        columnModel.getColumn(2).setPreferredWidth(100);
        columnModel.getColumn(3).setPreferredWidth(50);
        columnModel.getColumn(4).setPreferredWidth(100);
        columnModel.getColumn(5).setPreferredWidth(100);

        tableTareas.repaint();
    }


    private boolean validarCasilla(JTextField textField) {
        if (textField.getText() == null || textField.getText().isBlank()) {
            textField.setBackground(Application.BACKGROUND_ERROR);
            return false;
        } else {
            textField.setBackground(Color.WHITE);
            return true;
        }
    }
}
