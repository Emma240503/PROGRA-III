package pos.presentation.proyectos;
import pos.logic.Proyecto;
import pos.presentation.AbstractTableModel;
import java.util.List;

public class TableModelProyecto extends AbstractTableModel<Proyecto> implements javax.swing.table.TableModel {
    public TableModelProyecto(int[] cols, List<Proyecto> rows) {
        super(cols, rows);
    }

    public static final int CODIGO = 0;
    public static final int DESCRIPCION = 1;
    public static final int ENCARGADO = 2;
   public static final int NUMEROTAREAS = 3;

    @Override
    protected Object getPropetyAt(Proyecto e, int col) {
        switch (cols[col]) {
            case CODIGO: return e.getCodigo();
            case DESCRIPCION: return e.getDescripcion();
            case ENCARGADO: return e.getEncargado().getNombre();
            case NUMEROTAREAS: return e.getTareas().size();

            default: return "";
        }
    }

    @Override
    protected void initColNames() {
        colNames = new String[4];
        colNames[CODIGO] = "Codigo";
        colNames[DESCRIPCION] = "Descripcion";
        colNames[ENCARGADO] = "Encargado";
        colNames[NUMEROTAREAS] = "Numero de tareas";
    }
}

