package pos.presentation.proyectos;

import pos.logic.Proyecto;
import pos.logic.Service;
import pos.logic.Tarea;

import java.util.List;

public class Controller {
    View view;
    Model model;
     Service service;

    public Controller(View view, Model model) {

        this.view = view;
        this.model = model;
        service = Service.instance();
        view.setController(this);
        view.setModel(model);
    }

    public void crearTarea(Tarea tarea) {
        Proyecto proyectoActual = model.getCurrent();
        if (proyectoActual != null) {
            proyectoActual.agregarTarea(tarea);
            service.createTarea(tarea);
            model.actualizarTareasProyecto();
        }
    }

    public void crearProyecto(Proyecto proyecto) {
        service.createProyecto(proyecto);
        model.actualizarProyectos();


    }



}
