package pos.data;

import jakarta.xml.bind.annotation.*;
import pos.logic.*;
//import jakarta.xml.bind.annotation.*;

import javax.xml.namespace.QName;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Data {

    @XmlElementWrapper(name = "usuarios")
    @XmlElement(name = "usuario")
    private List<Usuario> usuarios;


    private List<Proyecto> proyectos;
    private List<Tarea> tareas;

    public Data() {
        usuarios = new ArrayList<>();
        proyectos = new ArrayList<>();
        tareas = new ArrayList<>();

        usuarios.add(new Usuario("118","Juan"));
        usuarios.add(new Usuario("119","Ana"));
        usuarios.add(new Usuario("120","Luis"));


    }
    public List<Usuario> getUsuarios() {
        return usuarios;
    }
    public List<Proyecto> getProyectos() {
        return proyectos;
    }
    public List<Tarea> getTareas() {
        return tareas;
    }

}
