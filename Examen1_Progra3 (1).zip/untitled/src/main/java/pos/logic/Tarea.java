package pos.logic;

public class Tarea {

    private String id;
    private String despripcion;
    private String fecha;
    private String estado;
    private String prioridad;
    Usuario usuario;

    public Tarea(String id, String despripcion, String fecha, String estado, String prioridad, Usuario usuario) {
        this.id = id;
        this.despripcion = despripcion;
        this.fecha = fecha;
        this.estado = estado;
        this.prioridad = prioridad;
        this.usuario = usuario;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDescripcion() {
        return despripcion;
    }
    public void setDespripcion(String despripcion) {
        this.despripcion = despripcion;
    }
    public String getFecha() {
        return fecha;

    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
    public String getPrioridad() {
        return prioridad;
    }
    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }
    public Usuario getUsuario(){
        return usuario;
    }
    public void setUsuario(Usuario usuario){
        this.usuario = usuario;
    }


}
