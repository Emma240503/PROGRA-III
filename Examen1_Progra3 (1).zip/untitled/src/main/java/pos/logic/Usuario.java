package pos.logic;

import jakarta.xml.bind.annotation.XmlElement;

public class Usuario {
    private String id;
    private String nombre;

    Usuario() {

    }

    public Usuario(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    @XmlElement
    public String getId() { return id; }

    @XmlElement
    public String getNombre() { return nombre; }

    @Override
    public String toString() {
        return nombre;
    }
}


