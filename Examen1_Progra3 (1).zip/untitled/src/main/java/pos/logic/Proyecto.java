
package pos.logic;

import java.util.ArrayList;
import java.util.List;

public class Proyecto {
    private static int contador = 0;
    private String codigo;
    private String descripcion;
    private Usuario encargado;
    private List<Tarea> tareas;

    public Proyecto(String descripcion, Usuario encargado,String codigo) {


        this.codigo = codigo ;
        this.descripcion = descripcion;
        this.encargado = encargado;
        this.tareas = new ArrayList<>();
    }

    public String getCodigo() { return codigo; }
    public String getDescripcion() { return descripcion; }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public Usuario getEncargado() { return encargado; }

    public void setEncargado(Usuario encargado) {

        this.encargado = encargado;
    }
    public void setTareas(List<Tarea> tareas) {
        this.tareas = tareas;
    }

    public List<Tarea> getTareas() { return tareas; }

    public void agregarTarea(Tarea tarea) {
        if (tarea == null) throw new IllegalArgumentException("No se puede agregar una tarea nula.");
        tareas.add(tarea);
        contador++;
    }


}
