package pos.logic;

import pos.data.Data;

import java.util.List;

public class Service {
    private static Service theInstance;

    public static Service instance() {
        if (theInstance == null) theInstance = new Service();
        return theInstance;
    }

    private Data data;

    public Data getData() {
        return data;
    }

    private Service() {
        try {
            data = pos.data.XmlPersister.instance().load();
        } catch (Exception e) {
            data = new Data();
        }
    }

    // ====================
    public void createTarea(Tarea tarea) {
        data.getTareas().add(tarea);
    }

    public List<Tarea> getTareas() {
        return data.getTareas();
    }

    // ====================
    public void createProyecto(Proyecto proyecto) {
        data.getProyectos().add(proyecto);
    }

    public List<Proyecto> findAll() {
        return data.getProyectos();
    }

    public List<Tarea> findAllTareas() {
        return data.getTareas();
    }
}
