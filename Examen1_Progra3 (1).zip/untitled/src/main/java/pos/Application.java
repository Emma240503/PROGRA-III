package pos;

import pos.logic.Proyecto;
import pos.logic.Tarea;
import pos.logic.Usuario;
import pos.presentation.proyectos.*;

import javax.swing.*;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.util.List;
import java.util.UUID;

public class Application {

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        doRun();
    }

    private static void doRun() {


        View view = new View();
        Model model = new Model();
        Controller controller = new Controller(view, model);

        JFrame window = new JFrame("Proyectos");
        window.setSize(800, 600);
        window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Proyectos", view.getPanel());

        window.setContentPane(tabs);
        window.setLocationRelativeTo(null);
        window.setVisible(true);
    }


    public final static int MODE_CREATE = 1;
    public final static int MODE_EDIT = 2;


    public static final Color BACKGROUND_ERROR = new Color(255, 102, 102, 255);
}