package Personas.logic;

public class Farmaceuta extends Trabajador{
    public Farmaceuta(String id, String name, String rol) {
        super(id, name, "Farmaceuta",id);
    }
    public Farmaceuta() {
        super();
    }
}
