package Personas.Presentation.Sesion.Contra;

import Personas.Logic.Farmaceuta;
import Personas.Logic.Medico;
import Personas.Logic.Service;
import Personas.Logic.Trabajador;
import Personas.Presentation.Sesion.Controller;
import Personas.Presentation.Sesion.Model;
import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class View extends JDialog implements PropertyChangeListener {
    private JPasswordField passwordFieldAntigua;
    private JPasswordField passwordFieldNueva;
    private JPasswordField passwordFieldNueva2;
    private JPanel panel1;
    private JButton guardarButton;
    private JTextField textFieldID;

    Controller controller;
    Model model;

    public View() {
        setContentPane(panel1);
        setModal(true);
        getRootPane().setDefaultButton(guardarButton);

        guardarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (validateSpots()) {
                    try {
                        cambio();
                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }
                } else {
                    JOptionPane.showMessageDialog(View.this, "Por favor, rellene todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // call onCancel() on ESCAPE
        panel1.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        // Aquí puedes manejar los cambios en el modelo si es necesario
    }

    public void setController(Controller controller) {
        this.controller = controller;
    }

    public void setModel(Model model) {
        this.model = model;
        model.addPropertyChangeListener(this);
    }

    public void cambio() throws Exception {
        // Lógica para guardar la nueva contraseña
        String id = textFieldID.getText();
        String antigua = new String(passwordFieldAntigua.getPassword());
        String nueva = new String(passwordFieldNueva.getPassword());
        String nueva2 = new String(passwordFieldNueva2.getPassword());
        Trabajador trabajador = new Trabajador();
        trabajador.setId(id);
        Trabajador trabajadorBD = Service.instance().readTrabajador(trabajador);

        if (trabajadorBD == null) {
            throw new Exception("Trabajador no encontrado");
        }

        // Validar contraseña antigua
        if (!trabajadorBD.getClave_sistema().equals(antigua)) {
            JOptionPane.showMessageDialog(View.this,
                    "La contraseña antigua es incorrecta",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            resetField(passwordFieldAntigua);
            resetField(passwordFieldNueva);
            resetField(passwordFieldNueva2);
            return;
        }

        // Validar que las nuevas contraseñas coincidan
        if (!nueva.equals(nueva2)) {
            JOptionPane.showMessageDialog(View.this,
                    "Las nuevas contraseñas no coinciden",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            resetField(passwordFieldNueva);
            resetField(passwordFieldNueva2);
            return;
        }

        // Validar que la nueva contraseña no esté vacía
        if (nueva.isEmpty()) {
            throw new Exception("La nueva contraseña no puede estar vacía");
        }

        // Actualizar la contraseña
        trabajadorBD.setClave_sistema(nueva);

        // Guardar en la base de datos según el tipo de trabajador
        try {
            // Intentar actualizar como Médico
            if (trabajadorBD instanceof Medico) {
                Service.instance().updateMedico((Medico) trabajadorBD);
            }
            // Intentar actualizar como Farmaceuta
            else if (trabajadorBD instanceof Farmaceuta) {
                Service.instance().updateFarmaceuta((Farmaceuta) trabajadorBD);
            }
            JOptionPane.showMessageDialog(View.this, "Contraseña cambiada con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (Exception e) {

        }
    }

    private void resetField(JTextField field) {
        field.setBackground(null);
        field.setToolTipText(null);
    }

    private boolean validateSpots() {
        boolean valido = true;
        if (passwordFieldAntigua.getText().isEmpty()) {
            passwordFieldAntigua.setBackground(Color.PINK);
            passwordFieldAntigua.setToolTipText("Este campo no puede estar vacío");
            valido = false;
        }
        if (passwordFieldNueva.getText().isEmpty()) {
            passwordFieldNueva.setBackground(Color.PINK);
            passwordFieldNueva.setToolTipText("Este campo no puede estar vacío");
            valido = false;
        }
        if (passwordFieldNueva2.getText().isEmpty()) {
            passwordFieldNueva2.setBackground(Color.PINK);
            passwordFieldNueva2.setToolTipText("Este campo no puede estar vacío");
            valido = false;
        }
        return valido;
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        panel1 = new JPanel();
        panel1.setLayout(new GridLayoutManager(5, 2, new Insets(10, 10, 10, 10), -1, -1));
        final JLabel label1 = new JLabel();
        label1.setText("ID:");
        panel1.add(label1, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label2 = new JLabel();
        label2.setText("Antigua Contraseña:");
        panel1.add(label2, new GridConstraints(1, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label3 = new JLabel();
        label3.setText("Nueva Contraseña:");
        panel1.add(label3, new GridConstraints(2, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label4 = new JLabel();
        label4.setText("Nueva Contraseña:");
        panel1.add(label4, new GridConstraints(3, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        passwordFieldNueva2 = new JPasswordField();
        panel1.add(passwordFieldNueva2, new GridConstraints(3, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        passwordFieldNueva = new JPasswordField();
        panel1.add(passwordFieldNueva, new GridConstraints(2, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        passwordFieldAntigua = new JPasswordField();
        passwordFieldAntigua.setText("");
        panel1.add(passwordFieldAntigua, new GridConstraints(1, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        textFieldID = new JTextField();
        panel1.add(textFieldID, new GridConstraints(0, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        guardarButton = new JButton();
        guardarButton.setIcon(new ImageIcon(getClass().getResource("/save.png")));
        guardarButton.setText("Guardar");
        panel1.add(guardarButton, new GridConstraints(4, 1, 1, 1, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return panel1;
    }
}
