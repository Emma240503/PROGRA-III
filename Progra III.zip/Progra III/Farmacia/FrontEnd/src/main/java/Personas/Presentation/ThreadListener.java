package Personas.Presentation;

public interface ThreadListener {
    public void refresh();
}
